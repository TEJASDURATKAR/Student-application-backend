const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/db.config");

const Course = sequelize.define("Courses", {
       course_id: {
              type: DataTypes.INTEGER,
              primaryKey: true,
              autoIncrement: true,
              allowNull: false
       },
       course_code: {
              type: DataTypes.STRING(20),
              allowNull: false,
              unique: true,
              validate: {
                     notEmpty: true,
                     len: [3, 20] // Ensures code is between 3-20 characters
              }
       },
       name: {
              type: DataTypes.STRING(100),
              allowNull: false,
              validate: {
                     notEmpty: true,
                     len: [5, 100] // Ensures name is meaningful
              }
       },
       description: {
              type: DataTypes.TEXT,
              allowNull: true,
              validate: {
                     len: [0, 2000] // Optional description with max length
              }
       },
       duration_months: {
              type: DataTypes.INTEGER,
              allowNull: true,
              validate: {
                     min: 1 // Minimum 1 month duration
              }
       },
       fee: {
              type: DataTypes.DECIMAL(10, 2),
              allowNull: false,
              validate: {
                     min: 0 // Fee can't be negative
              }
       },
       is_active: {
              type: DataTypes.BOOLEAN,
              defaultValue: true
       }
}, {
       timestamps: true, // Automatically handles createdAt and updatedAt
});

module.exports = Course;