import { DataTypes } from "sequelize";
const { sequelize } = require("../config/db.config");

const Role = sequelize.define("Role", {
  role_id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  role_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  role: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  permission: {
    type: DataTypes.TEXT,
    allowNull: false,
  }
}, {
  tableName: 'roles',
  timestamps: true,
});

export default Role;
