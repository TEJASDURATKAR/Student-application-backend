const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/db.config");

const Batches = sequelize.define("batches", {
       batch_id: {
              type: DataTypes.INTEGER,
              primaryKey: true,
              autoIncrement: true,
              allowNull: false
       },
       batch_code: {
              type: DataTypes.STRING(20),
              allowNull: false,
              unique: true
       },
       course_id: {
              type: DataTypes.INTEGER,
              allowNull: true,
              unique: true,
              references: {
                     model: "courses",
                     key: "course_id"
              }
       },
       name: {
              type: DataTypes.STRING(100),
              allowNull: false,
       },
       start_date: {
              type: DataTypes.DATEONLY,
              allowNull: false,
       },
       end_date: {
              type: DataTypes.DATEONLY,
              allowNull: false,
       },
       max_students: {
              type: DataTypes.INTEGER,
              allowNull: false,
              validate: {
                     min: 1
              }
       },
       current_students: {
              type: DataTypes.INTEGER,
              allowNull: true,
       },
       status: {
              type: DataTypes.ENUM('active', 'inactive', 'completed', 'suspended'),
              defaultValue: "active",
              allowNull: false
       },
}, {
       timestamps: true, // Automatically manages createdAt and updatedAt
});

module.exports = Batches;