import express from 'express';
import {
  createRole,
  getAllRoles,
  getRoleById,
  updateRole,
  deleteRole
} from '../controllers/roleController';

export const roleRouter = express.Router();

// CRUD Routes
roleRouter.post("/", createRole);
roleRouter.get("/", getAllRoles);
roleRouter.get("/:id", getRoleById);
roleRouter.put("/:id", updateRole);
roleRouter.delete("/:id", deleteRole);
