const express = require('express');
import { createEnquiry, getAllEnquiries, getEnquiryById, updateEnquiry, deleteEnquiry } from '../controllers/enquiryController.js'

export const enquiryRouter = express.Router();

// CRUD Routes
enquiryRouter.post("/", createEnquiry);
enquiryRouter.get('/', getAllEnquiries);
enquiryRouter.get('/:enquiryId', getEnquiryById);
enquiryRouter.put('/:enquiryId', updateEnquiry);
enquiryRouter.delete('/:enquiryId', deleteEnquiry);

