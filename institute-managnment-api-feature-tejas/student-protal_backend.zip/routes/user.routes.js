
import multer from "multer";
import express from "express";
import { verifyJWT } from "../middlewares/jwt";
import { mustBeUser, mustBeVendor } from "../middlewares/authorization";
import { validateUserLogin } from "../middlewares/user.middleware";
import { storage } from "../config/multer.config";
import {
  changePassword, deleteVendor, updateVendor,
  forgetPassword, getAllVendor, getOneVendor,
  login, registerUser, registerVendor, verifyOTP, registerCompanyDetails, resetVerifyOtp,
  resetPassword,
  addUser,
  deleteUser,
  updateUser,
  getUser,
} from "../controllers/user.controller";

// const customerController = require ("../controllers/customerlogin.controller")

// Multer Configuration
const upload = multer({
  storage: storage
});

export const userRouter = express.Router();

// Global Routes
userRouter.post("/login", login)
userRouter.post("/addUser", addUser)
userRouter.get("/getuser", getUser)
userRouter.put("/updateUser", updateUser)
userRouter.delete("/deleteUser", deleteUser)


// userRouter.post("/register-vendor", [upload.single('image')], registerVendor)
// userRouter.get('/all-vendor', getAllVendor),
// userRouter.get('/one-vendor', getOneVendor),
// userRouter.put('/update-vendor', updateVendor),
// userRouter.delete('/delete-vendor', deleteVendor),

// userRouter.post("/register-user", [upload.single('image')], registerUser)

// userRouter.post("/forget-password", forgetPassword)
// userRouter.post("/reset-VerifyOtp", resetVerifyOtp)
// userRouter.post("/verify-otp", verifyOTP)
// userRouter.post("/change-password", changePassword)
// userRouter.post("/reset-password", resetPassword)


// for customer
// userRouter.post("/verify-OTP-Customer", customerController.verifyOTPAndRegister)
// userRouter.post("/loginCustomer", customerController.loginCustomer)
// userRouter.post("/register-Customer", customerController.registerCustomer)
// userRouter.get("/all-customers", customerController.getAllCustomers)
// userRouter.post("/addCustomerProfile", [upload.single('image')], customerController.addCustomerProfile)
// userRouter.post("/getCustomerProfile", customerController.getCustomerProfile)

// other routes come below verifyJwt which are not global
// userRouter.use(verifyJWT);

// userRouter.post("/register-compnay", [mustBeVendor], registerCompanyDetails)
