import response from "../const/response";

const Joi = require("joi");

// Define a schema for the request body
const vehicleInfoSchema = Joi.object({
  vehicle_type: Joi.string().required(),
  seating_capacity: Joi.string().required(),
  vihicle_image: Joi.string().required(),
  rate_per_km: Joi.string().integer().required(),
  rent: Joi.string().required()
});

export const validatevehicleInfo = async (req, res, next) => {
  const { error } =  vehicleInfoSchema.validate(req.body);
  if (error) {
    const normalizedError = {
      type: "ValidationError",
      message: "Invalid Input. Please Check Again",
      errors: error.details.map((detail) => ({
        field: detail.path.join("."),
        message: detail.message
      }))
    };
    return response.somethingErrorMsgResponse(res, 400, normalizedError.message, {});
  }
  // Validate if User exist or not
  return next();

};
