import response from "../const/response";

const Joi = require("joi");

// Define a schema for the request body
const vehicleInfoSchema = Joi.object({
  vehicle_type: Joi.string().required(),
  seating_capacity: Joi.string().required(),
  vihicle_image: Joi.string().required(),
  rate_per_km: Joi.string().integer().required(),
  rent: Joi.string().required()
});

export const validatevehicleInfo = async (req, res, next) => {
  const { error } =  vehicleInfoSchema.validate(req.body);
  if (error) {
    const normalizedError = {
      type: "ValidationError",
      message: "Invalid Input. Please Check Again",
      errors: error.details.map((detail) => ({
        field: detail.path.join("."),
        message: detail.message
      }))
    };
    return response.somethingErrorMsgResponse(res, 400, normalizedError.message, {});
  }
  // Validate if Vehical exist or not
  return next();
};

const BusInfoSchema = Joi.object({
  numberOf_buses: Joi.string().integer().required(),
  seating_capacity: Joi.string().integer().required(),
  bus_image: Joi.string().required(),
  ac_or_nonAc: Joi.string().required(),
  ratePer_km: Joi.string().integer().required(),
})

export const validateBusInfo = async (req, res, next) => {
  const { error } =  BusInfoSchema.validate(req.body);
  if (error) {
    const normalizedError = {
      type: "ValidationError",
      message: "Invalid Input. Please Check Again",
      errors: error.details.map((detail) => ({
        field: detail.path.join("."),
        message: detail.message
      }))
    };
    return response.somethingErrorMsgResponse(res, 400, normalizedError.message, {});
  }
  // Validate if BusInfo exist or not
  return next();
};

// Define a schema for the request body
const CarInfoSchema = Joi.object({
  numberOf_car: Joi.string().integer().required(),
  seating_capacity: Joi.string().integer().required(),
  car_image: Joi.string().required(),
  ac_or_nonAc: Joi.string().required(),
  ratePer_km: Joi.string().integer().required(),
});

export const validateCarInfo = async (req, res, next) => {
  const { error } =  CarInfoSchema.validate(req.body);
  if (error) {
    const normalizedError = {
      type: "ValidationError",
      message: "Invalid Input. Please Check Again",
      errors: error.details.map((detail) => ({
      field: detail.path.join("."),
      message: detail.message
      }))
    };
    return response.somethingErrorMsgResponse(res, 400, normalizedError.message, {});
  }
  // Validate if CarInfo exist or not
  return next();
};

// Define a schema for the request body
const OtherVehicalSchema = Joi.object({
  numberOf_car: Joi.string().integer().required(),
  seating_capacity: Joi.string().integer().required(),
  car_image: Joi.string().required(),
  ac_or_nonAc: Joi.string().required(),
  ratePer_km: Joi.string().integer().required(),
});

export const validateOtherVehical = async (req, res, next) => {
  const { error } = OtherVehicalSchema.validate(req.body);
  if (error) {
      const normalizedError = {
          type: "ValidationError",
          message: "Invalid Input. Please Check Again",
          errors: error.details.map((detail) => ({
              field: detail.path.join("."),
              message: detail.message
          }))
      };
      return response.somethingErrorMsgResponse(res, 400, normalizedError.message, {});
  }
  // Validate if OtherVehicalInfo exist or not
  return next();
};