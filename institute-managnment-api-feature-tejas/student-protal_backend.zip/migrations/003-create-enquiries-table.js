"use strict";

const { ref } = require('joi');

/** @type {import('sequelize-cli').Migration} */
module.exports = {
       async up(queryInterface, Sequelize) {
              await queryInterface.createTable("Enquiries ", {
                     enquiry_id: {
                            type: Sequelize.INTEGER,
                            allowNull: false,
                            primaryKey: true,
                            autoIncrement: true,
                     },
                     name: {
                            type: Sequelize.STRING(50),
                            allowNull: false,
                     },
                     email: {
                            type: Sequelize.STRING(100),
                            allowNull: false,
                     },
                     phone: {
                            type: Sequelize.STRING(20),
                            allowNull: true
                     },
                     course_intrested: {
                            type: Sequelize.STRING(100),
                            allowNull: false,
                     },
                     source: {
                            type: Sequelize.STRING(50),
                            allowNull: false,
                            comment: 'How they heard about us'
                     },
                     is_active: {
                            type: Sequelize.BOOLEAN,
                            defaultValue: true
                     },
                     status: {
                            type: Sequelize.STRING(20),
                            defaultValue: 'new',
                            allowNull: false
                     },
                     followup_date: {
                            type: Sequelize.DATE,
                            allowNull: true
                     },
                     handled_by: {
                            type: Sequelize.INTEGER,
                            allowNull: true,
                            ref: {
                                   model: 'Users',
                                   key: 'user_id'
                            }
                     },
                     created_at: {
                            type: Sequelize.DATE,
                            defaultValue: Sequelize.literal("CURRENT_TIMESTAMP")
                     },
                     updated_at: {
                            type: Sequelize.DATE,
                            defaultValue: Sequelize.literal("CURRENT_TIMESTAMP")
                     },
              });
       },

       async down(queryInterface, Sequelize) {
              await queryInterface.dropTable("Enquiries");
       }
};