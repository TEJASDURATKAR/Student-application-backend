"use strict";

/** @type {import('sequelize-cli').Migration} */
module.exports = {
       async up(queryInterface, Sequelize) {
              await queryInterface.createTable("Batches", {
                     batch_id: {
                            type: Sequelize.INTEGER,
                            primaryKey: true,
                            autoIncrement: true,
                            allowNull: false
                     },
                     batch_code: {
                            type: Sequelize.STRING(20),
                            allowNull: false,
                            unique: true
                     },
                     course_id: {
                            type: Sequelize.INTEGER,
                            allowNull: false,
                            references: {
                                   model: "Courses",
                                   key: "course_id"
                            }
                     },
                     name: {
                            type: Sequelize.STRING(100),
                            allowNull: false
                     },
                     start_date: {
                            type: Sequelize.DATEONLY,
                            allowNull: false
                     },
                     end_date: {
                            type: Sequelize.DATEONLY,
                            allowNull: false
                     },
                     max_students: {
                            type: Sequelize.INTEGER,
                            allowNull: true
                     },
                     current_students: {
                            type: Sequelize.INTEGER,
                            defaultValue: 0
                     },
                     status: {
                            type: Sequelize.STRING(20),
                            values: ['upcoming', 'ongoing', 'completed'],
                            defaultValue: "upcoming"
                     },
                     teacher_id: {
                            type: Sequelize.INTEGER,
                            allowNull: true,
                            references: {
                                   model: "Users",
                                   key: "user_id"
                            }
                     },
                     created_at: {
                            type: Sequelize.DATE,
                            defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
                            allowNull: false
                     }
              });
       },

       async down(queryInterface, Sequelize) {
              await queryInterface.dropTable("Batches");
       }
};