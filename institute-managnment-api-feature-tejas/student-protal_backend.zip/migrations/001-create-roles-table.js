"use strict";

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("roles", {
  role_id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true,
    field: "role_id"
  },
  role_name: {
    type: Sequelize.STRING(100),
    allowNull: false
  },
  role: {
    type: Sequelize.STRING(50),
    allowNull: false,
    unique: true // prevent duplicate role values like "admin"
  },
  permission: {
    type: Sequelize.TEXT,
    allowNull: false
  },
  created_at: {
    type: Sequelize.DATE,
    defaultValue: Sequelize.literal("CURRENT_TIMESTAMP")
  },
  updated_at: {
    type: Sequelize.DATE,
    defaultValue: Sequelize.literal("CURRENT_TIMESTAMP")
  }
});

  },

  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("roles");
  }
};
