"use strict";

/** @type {import('sequelize-cli').Migration} */
module.exports = {
       async up(queryInterface, Sequelize) {
              await queryInterface.createTable("Courses", {
                     course_id: {
                            type: Sequelize.INTEGER,
                            primaryKey: true,
                            autoIncrement: true,
                            allowNull: false
                     },
                     course_code: {
                            type: Sequelize.STRING(20),
                            allowNull: false,
                            unique: true
                     },
                     name: {
                            type: Sequelize.STRING(100),
                            allowNull: false
                     },
                     description: {
                            type: Sequelize.TEXT,
                            allowNull: true
                     },
                     duration_months: {
                            type: Sequelize.INTEGER,
                            allowNull: true
                     },
                     fee: {
                            type: Sequelize.DECIMAL(10, 2),
                            allowNull: false
                     },
                     is_active: {
                            type: Sequelize.BOOLEAN,
                            defaultValue: true
                     },
                     created_at: {
                            type: Sequelize.DATE,
                            defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
                            allowNull: false
                     }
              });
       },

       async down(queryInterface, Sequelize) {
              await queryInterface.dropTable("Courses");
       }
};