import Enquiry from "../models/Enquiry";


// CREATE
export const createEnquiry = async (req, res) => {
       try {
              console.log(req.body)
              const enquiry = await Enquiry.create(req.body);
              return res.status(201).send(enquiry);
       } catch (error) {
              return res.status(400).send(error);
       }
}

// READ (all)
export const getAllEnquiries = async (req, res) => {
       try {
              const enquiries = await Enquiry.findAll({});
              return res.status(200).send(enquiries);
       } catch (error) {
              return res.status(400).send(error);
       }
}

// READ (single)
export const getEnquiryById = async (req, res) => {
       try {
              console.log(req.params)
              const enquiry = await Enquiry.findByPk(req.params.enquiryId, {});
              console.log(enquiry)

              if (!enquiry) {
                     return res.status(404).send({
                            message: 'Enquiry Not Found',
                     });
              }

              return res.status(200).send(enquiry);
       } catch (error) {
              return res.status(400).send(error);
       }
}

// UPDATE
export const updateEnquiry = async (req, res) => {
       try {
              const enquiry = await Enquiry.findByPk(req.params.enquiryId);

              if (!enquiry) {
                     return res.status(404).send({
                            message: 'Enquiry Not Found',
                     });
              }

              const updatedEnquiry = await enquiry.update(req.body);
              return res.status(200).send(updatedEnquiry);
       } catch (error) {
              return res.status(400).send(error);
       }
}

// DELETE
export const deleteEnquiry = async (req, res) => {
       try {
              const enquiry = await Enquiry.findByPk(req.params.enquiryId);

              if (!enquiry) {
                     return res.status(404).send({
                            message: 'Enquiry Not Found',
                     });
              }

              await enquiry.destroy();
              return res.status(204).send();
       } catch (error) {
              return res.status(400).send(error);
       }
}
