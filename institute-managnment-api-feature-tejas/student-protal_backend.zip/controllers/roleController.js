import Role from '../models/Role';

// CREATE
export const createRole = async (req, res) => {
  try {
    const { role_name, role, permission } = req.body;

    if (!role_name || !role || !permission) {
      return res.status(400).json({
        success: false,
        message: "All fields are required"
      });
    }

    const newRole = await Role.create({
      role_name,
      role,
      permission
    });

    res.status(201).json({
      success: true,
      message: "Role created successfully",
      data: newRole
    });

  } catch (error) {
    console.error("Create role error:", error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// GET ALL
export const getAllRoles = async (req, res) => {
  try {
    const roles = await Role.findAll();
    res.json({ success: true, data: roles });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET ONE
export const getRoleById = async (req, res) => {
  try {
    const role = await Role.findByPk(req.params.id);
    if (!role) return res.status(404).json({ success: false, message: "Role not found" });
    res.json({ success: true, data: role });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// UPDATE
export const updateRole = async (req, res) => {
  try {
    const role = await Role.findByPk(req.params.id);
    if (!role) return res.status(404).json({ success: false, message: "Role not found" });

    await role.update(req.body);
    res.json({ success: true, data: role });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// DELETE
export const deleteRole = async (req, res) => {
  try {
    const role = await Role.findByPk(req.params.id);
    if (!role) return res.status(404).json({ success: false, message: "Role not found" });

    await role.destroy();
    res.json({ success: true, message: "Role deleted successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
