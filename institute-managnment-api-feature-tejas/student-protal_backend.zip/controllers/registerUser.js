import sendEmail from "../utils/sendEmail.js";

export const registerUser = async (req, res) => {
  const { email, name } = req.body;

  try {
    // Save user logic here...

    const subject = "Welcome to Techo!";
    const body = `<h1>Hello ${name}</h1><p>Thank you for registering.</p>`;
    await sendEmail(email, subject, body);

    res.status(201).json({ message: "User registered and email sent." });
  } catch (err) {
    console.error("❌ Error in registerUser:", err);
    res.status(500).json({ message: "Internal server error" });
  }
};
