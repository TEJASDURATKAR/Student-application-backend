import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { JWT_KEY } from "../const/credentials";
import User from "../models/User";
import response from "../const/response";
import { HTTP_MESSAGES } from "../const/message";
import { generateTempPassword } from "../utils/tempPassword";
import { sendMail } from "../utils/sendEmail";
import Role from "../models/Role";

export const login = async (req, res) => {
  const { username, password } = req.body;
  // Find the user with the provided username
  const user = await User.findOne({
    where: {
      username,
      is_active: true,
      is_deleted: false,
    },
    attributes: {
      exclude: ["is_deleted", "token", "created_at", "updated_at", "is_active"],
    },
  });

  if (!user) {
    return response.successResponse(res, 404, {}, HTTP_MESSAGES.EN.AUTH_ERROR);
  }

  // If the user is found, compare the password provided with the hashed password in the database
  if (await bcrypt.compare(password, user.password)) {
    // Fetch Other Details By Role
    //   const profile = await _getUserProfile(user.id, user.role);

    // Generate JWT Token
    const token = jwt.sign(
      {
        _id: user.id,
        username: user.username,
        role: user.role,
      },
      JWT_KEY,
      {
        expiresIn: "24h",
      },
    );
    // If the password is correct, send a success response with the JWT token
    // unset password
    user.password = undefined;
    return response.successResponse(
      res,
      200,
      { access_token: token, user },
      HTTP_MESSAGES.EN.LOGIN_SUCCESS,
    );
  }
  // If the password is incorrect, send a 404 response
  return response.successResponse(
    res,
    404,
    {},
    HTTP_MESSAGES.EN.USER_NOT_FOUND,
  );
};

export const getUser = async (req, res) => {
  try {
    const users = await User.findAll({
      attributes: { exclude: ["password"] } // hides the password column
    });

    return res.status(200).json({
      message: "User data fetched successfully",
      data: users,
    });
  } catch (error) {
    console.error("get user error", error);
    return res.status(500).json({
      message: "Failed to fetch user data",
      error,
    });
  }
};

export const addUser = async (req, res) => {
  try {
    const { username, full_name, email, role } = req.body;

    // 1. Generate temp password
    const temppassword = generateTempPassword();
    const hashedPassword = await bcrypt.hash(temppassword, 10);

    // 2. Check if role exists, if not, create
    let roleData = await Role.findOne({ where: { role_id: role } });

    if (!roleData) {
      roleData = await Role.create({ role_name: role });
    }

    const roleId = roleData.role_id; // ensure this matches your DB column

    // 3. Create user
    const newUser = await User.create({
      username,
      full_name,
      email,
      password: hashedPassword,
      role_id: roleId,
    });

    // 4. Send email
    const message = `Your Password
Hello,
Here is your username and password:
Username: ${username}
Password: ${temppassword}
Role: ${role}
Please keep this password confidential and do not share it with anyone.
Thank you!`;

    const subject = "Sending Username and Password";
    const emailResponse = await sendMail(email, subject, message);

    return res.status(200).json({
      message: `${HTTP_MESSAGES.EN.DATA_ADDED_SUCCESS} ${emailResponse}`,
      user: newUser,
    });
  } catch (error) {
    console.error("add user error", error);
    return res.status(500).json({
      message: HTTP_MESSAGES.EN.DATA_ADDED_FAILED,
      error: error.message,
    });
  }
};


export const updateUser = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) {
      return res.status(401).json({ message: "No token provided" });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.id;

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const { full_name, username, email } = req.body;

    if (full_name) user.full_name = full_name;
    if (username) user.username = username;
    if (email) user.email = email;

    await user.save();

    const updatedUser = {
      id: user.id,
      full_name: user.full_name,
      username: user.username,
      email: user.email,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    };

    return res.status(200).json(updatedUser);
  } catch (error) {
    if (error.name === "JsonWebTokenError") {
      return res.status(401).json({ message: "Invalid token" });
    }
    if (error.name === "SequelizeUniqueConstraintError") {
      return res.status(400).json({ message: "Email already in use" });
    }
    return res
      .status(500)
      .json({ message: "Server error", error: error.message });
  }
};

export const deleteUser = async (req, res) => {
  try {
    // console.log(req.params.userid)
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1];

    if (!token) {
      return res.status(401).send({ message: "No token provided" });
    }

    // console.log("delete:", token)
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const userId = decoded.id;

    const user = await User.findByPk(userId);

    if (!user) {
      return res.status(404).send({
        message: "User Not Found",
      });
    }

    await user.destroy();
    return res
      .status(204)
      .send({ message: HTTP_MESSAGES.EN.DATA_DELETED_SUCCESS });
  } catch (error) {
    return res.status(400).send(error);
  }
};
