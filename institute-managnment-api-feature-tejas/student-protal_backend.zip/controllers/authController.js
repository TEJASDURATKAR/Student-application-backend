import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import User from "../models/User.js"; // if your file is named user.model.js
import { HTTP_MESSAGES } from '../const/message.js'
const JWT_SECRET = process.env.JWT_SECRET;

export const signup = async (req, res) => {
  try {
    const { email, username, full_name, password, role, mobile_number, address } = req.body;

    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      return res.status(400).json({ message: HTTP_MESSAGES.EN.DATA_ADDED_FAILED });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = await User.create({
      email,
      username,
      full_name,
      password_hash: hashedPassword,
      role,
      mobile_number,
      address
    });

    return res.status(201).json({ message: HTTP_MESSAGES.EN.DATA_ADDED_SUCCESS, user: newUser });
  } catch (error) {
    console.error("Signup Error:", error);
    return res.status(500).json({ message: HTTP_MESSAGES.EN.SERVER_ERROR });
  }
};


export const signin = async (req, res) => {
  try {
    console.log(req.body)
    const { username, password } = req.body;

    const user = await User.findOne({ where: { username } });
    console.log(user)
    if (!user) {
      return res.status(404).json({ message: HTTP_MESSAGES.EN.USER_NOT_FOUND });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);

    if (!isPasswordValid) {
      return res.status(401).json({ message: HTTP_MESSAGES.EN.AUTH_ERROR });
    }

    // Generate JWT Token with temp key
    const token = jwt.sign(
      { id: user.user_id, username: user.username, role: user.role },
      process.env.JWT_SECRET,  // <--- temp key
      { expiresIn: "24h" }
    );

    // Log token in console
    console.log("JWT Token:", token);

    // Generate OTP
    // const otp = Math.floor(100000 + Math.random() * 900000);
    // user.Otp = otp;
    // await user.save();

    return res.status(200).json({
      message: HTTP_MESSAGES.EN.LOGIN_SUCCESS,
      user: {
        id: user.user_id,
        email: user.email,
        username: user.username,
        full_name: user.full_name,
        role: user.role,
        mobile_number: user.mobile_number,
        address: user.address,
        // Otp: user.Otp
        token
      }

    });

  } catch (error) {
    console.error("Signin Error:", error);
    return res.status(500).json({ message: HTTP_MESSAGES.EN.SERVER_ERROR });
  }
};

// controllers/authController.js
export const changePassword = async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body;
    const userId = req.user.id; // comes from verifyToken

    const user = await User.findByPk(userId);
    if (!user) return res.status(404).json({ message: HTTP_MESSAGES.EN.USER_NOT_FOUND });

    const isPasswordValid = await bcrypt.compare(oldPassword, user.password_hash);
    if (!isPasswordValid) {
      return res.status(400).json({ message: HTTP_MESSAGES.EN.OLD_PASSWORD_INC });
    }

    const hashedNewPassword = await bcrypt.hash(newPassword, 10);
    user.password_hash = hashedNewPassword;
    await user.save();

    res.status(200).json({ message: HTTP_MESSAGES.EN.PASSWORD_CHANGE_SUCCESSFUL });
  } catch (error) {
    console.error("ChangePassword Error:", error);
    res.status(500).json({ message: HTTP_MESSAGES.EN.SERVER_ERROR });
  }
};

export const forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ message: HTTP_MESSAGES.EN.EMAIL_IS_REQUIRED });
    }

    const user = await User.findOne({ where: { email } });
    if (!user) return res.status(404).json({ message: HTTP_MESSAGES.EN.USER_NOT_FOUND });

    const otp = Math.floor(100000 + Math.random() * 900000);
    user.Otp = otp;
    await user.save();

    console.log(`OTP for ${email}: ${otp}`);
    res.status(200).json({ message: HTTP_MESSAGES.EN.OTP_SENTON_EMAIL });
  } catch (error) {
    console.error("ForgotPassword Error:", error);
    res.status(500).json({ message: HTTP_MESSAGES.EN.SERVER_ERROR });
  }
};


export const resetPassword = async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;

    const user = await User.findOne({ where: { email } });
    if (!user) return res.status(404).json({ message: HTTP_MESSAGES.EN.USER_NOT_FOUND });

    console.log("User otp from DB:", user.otp);
    console.log("OTP from request:", otp);

    if (!user.otp || user.otp != otp) {
      return res.status(400).json({ message: HTTP_MESSAGES.EN.INVALD_OTP });
    }

    const hashedNewPassword = await bcrypt.hash(newPassword, 10);
    user.password_hash = hashedNewPassword;
    user.otp = null; // clear OTP
    await user.save();

    res.status(200).json({ message: HTTP_MESSAGES.EN.PASSWORD_CHANGE_SUCCESSFUL });
  } catch (error) {
    console.error("ResetPassword Error:", error);
    res.status(500).json({ message: HTTP_MESSAGES.EN.SERVER_ERROR });
  }
};





// export const updateProfile = async (req, res) => {
//   try {
//     const userId = req.user.id;
//     const { full_name, mobile_number, address } = req.body;

//     const user = await User.findByPk(userId);
//     if (!user) return res.status(404).json({ message: "User not found" });

//     user.full_name = full_name || user.full_name;
//     user.mobile_number = mobile_number || user.mobile_number;
//     user.address = address || user.address;

//     await user.save();

//     res.status(200).json({ message: "Profile updated successfully", user });
//   } catch (error) {
//     console.error("UpdateProfile Error:", error);
//     res.status(500).json({ message:HTTP_MESSAGES.EN.SERVER_ERROR });
//   }
// };
