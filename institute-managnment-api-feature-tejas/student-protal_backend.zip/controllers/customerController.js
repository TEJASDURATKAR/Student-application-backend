import Customer from "../models/Customer";


// Create Customer
export const createCustomer = async (req, res) => {
  try {
    const customer = await Customer.create(req.body);
    res.status(201).json(customer);
  } catch (error) {
    res.status(500).json({ message: "Failed to create customer", error });
  }
};

// Get All Customers
export const  getAllCustomers = async (req, res) => {
  try {
    const customers = await Customer.findAll();
    res.status(200).json(customers);
  } catch (error) {
    res.status(500).json({ message: "Failed to retrieve customers", error });
  }
};

// Get Customer by ID
export const getCustomerById = async (req, res) => {
  try {
    const customer = await Customer.findByPk(req.params.id);
    if (!customer) return res.status(404).json({ message: "Customer not found" });
    res.status(200).json(customer);
  } catch (error) {
    res.status(500).json({ message: "Failed to retrieve customer", error });
  }
};

// Update Customer
export const updateCustomer = async (req, res) => {
  try {
    const [updated] = await Customer.update(req.body, {
      where: { customer_id: req.params.id }
    });
    if (!updated) return res.status(404).json({ message: "Customer not found" });
    const updatedCustomer = await Customer.findByPk(req.params.id);
    res.status(200).json(updatedCustomer);
  } catch (error) {
    res.status(500).json({ message: "Failed to update customer", error });
  }
};

// Delete Customers
export const deleteCustomer = async (req, res) => {
  try {
    const deleted = await Customer.destroy({
      where: { customer_id: req.params.id }
    });
    if (!deleted) return res.status(404).json({ message: "Customer not found" });
    res.status(200).json({ message: "Customer deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Failed to delete customer", error });
  }
};
